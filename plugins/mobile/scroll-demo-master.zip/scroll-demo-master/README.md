how to check? open with index.html
