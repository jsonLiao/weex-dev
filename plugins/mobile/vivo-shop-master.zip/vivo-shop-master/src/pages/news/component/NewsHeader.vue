<template>
  <div class="header">
      <div>资讯动态</div>
  </div>
</template>

<script>
export default {
  
}
</script>


<style lang="stylus" scoped>
  .header
    width 100%
    height 1.45rem
    line-height 1.45rem
    font-size: 0.45rem;
    text-align center
    background #fff
    position fixed
</style>