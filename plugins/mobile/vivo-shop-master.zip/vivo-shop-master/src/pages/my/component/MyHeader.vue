<template>
  <div class="header">
      <div class="header-left">
          <i class="iconfont icon-zuojiantou"></i>
      </div>
      <div class="header-in">个人中心</div>
      <div class="header-rigth">
          <i class="iconfont icon-shezhi-xianxing"></i>
      </div>
  </div>
</template>

<script>

</script>

<style lang="stylus" scoped>
    .header
        width 100%;
        height 1.45rem;
        background #ffffff
        .header-left 
            width 10%
            float left;
            i 
                font-size .6rem
                line-height 1.45rem
                text-align center
                display block
        .header-in
            width 80%
            float left
            text-align center
            font-size .45rem
            line-height 1.45rem
        .header-rigth
            width 10%
            float left
            i
                font-size .6rem
                line-height 1.45rem
                text-align center
                display block
</style>