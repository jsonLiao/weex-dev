export const SET_CARTS = 'SET_CARTS'  //加入购物车
export const SET_ARTICLE ='SET_ARTICLE' //文章收藏
export const SET_GOODS='SET_GOODS' //商品收藏
export const SET_ORDERS='SET_ORDERS' //订单
export const SET_ADDRESS='SET_ADDRESS' //地址